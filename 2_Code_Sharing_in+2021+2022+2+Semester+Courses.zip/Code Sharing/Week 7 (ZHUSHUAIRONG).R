#Correlation with built in data-set
View(state.x77)
states<- state.x77[,1:6]
cor(states)
summary(states)

#Importing example Data-set
library(readxl)
Dataset1 <- read_excel("")
View(Dataset1)

#Correlation with example data-set
cor(Dataset1$DAX, Dataset1$FTSE)

#Linear Regression
result <- lm(DAX ~ FTSE , data=Dataset1)
summary(result)

#Regression Graph
plot(Dataset1$DAX,Dataset1$FTSE,
     xlab="FTSE",
     ylab="DAX")

#Regression Line
abline(result)
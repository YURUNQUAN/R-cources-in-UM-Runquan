library(ggplot2)
library(tibble)

library(effsize)
library(pwr)
library(ggpubr)
options(scipen = 200)

#Presentation for the dataset that GESTdata and data
read.csv("/Users/yu.run.q/Desktop/data.csv")
B = read.csv("/Users/yu.run.q/Desktop/data.csv")

p1 <- ggscatter(B,x="Emmtion",y="Quality",color="#009999",size=3,xlab="Emotion",ylab="Sleep Quality",add="reg.line",add.params = list(color="black",fill="gray"),conf.int=TRUE)
p1
p1+stat_cor()

p2 <- ggscatter(B,x="Emmtion",y="Happiness",color="#009999",size=3,xlab="Emotion",ylab="Happiness Degree",add="reg.line",add.params = list(color="black",fill="gray"),conf.int=TRUE)
p2
p2+stat_cor()

read.csv("/Users/yu.run.q/Desktop/GESTdata.csv")
C1 = read.csv("/Users/yu.run.q/Desktop/GESTdata.csv")

ggplot(data = C1, mapping = aes(x = Condition, y = Group_A))+
  geom_point()+
  geom_line(aes(group = Sub))


#Presentation part 2; for the dataset 1
read.csv("/Users/yu.run.q/Desktop/Dataset1.csv")
E3 = read.csv("/Users/yu.run.q/Desktop/Dataset1.csv")
p5 <- ggscatter(E3,x="Emotion",y="Happiness",color="#009999",size=3,xlab="Emotion",ylab="Happy",add="reg.line",add.params = list(color="black",fill="gray"),conf.int=TRUE)
p5
p5+stat_cor()

p6 <- ggscatter(E3,x="Emotion",y="Sleep",color="#009999",size=3,xlab="Emotion",ylab="Sleep Quality",add="reg.line",add.params = list(color="black",fill="gray"),conf.int=TRUE)
p6
p6+stat_cor()

p7 <- ggscatter(E3,x="Sleep",y="Happiness",color="#009999",size=3,xlab="Sleep",ylab="Happiness",add="reg.line",add.params = list(color="black",fill="gray"),conf.int=TRUE)
p7
p7+stat_cor()

library(gridExtra)
Q1= ggviolin(E3,y="Sleep",fill="#00AFBB",palette=c("#00AFBB", "#E7B800"),xlab="Sleep Time",ylab="Time",size=1,width=0.35,add="boxplot",add.params=list(fill="white"))
Q1 = ggpar(P1,ylim = c(-2, 3),font.main = c(11,"bold"),font.x =c(11,"bold"),font.y=c(11,"bold") )
Q1


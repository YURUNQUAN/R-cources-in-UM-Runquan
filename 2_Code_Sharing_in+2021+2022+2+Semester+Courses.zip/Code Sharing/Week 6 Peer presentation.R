library(readxl)
Dataset1 <- read_excel("D:/R Language/Dataset1.xlsx")
View(Dataset1)

library(readxl)
Dataset2 <- read_excel("D:/R Language/Dataset2.xlsx")
View(Dataset2)

library(readxl)
Dataset3 <- read_excel("D:/R Language/Dataset3.xlsx")
View(Dataset3)
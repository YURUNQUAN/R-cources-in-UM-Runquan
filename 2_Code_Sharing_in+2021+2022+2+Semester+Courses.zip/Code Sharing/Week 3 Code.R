# code for Week_3_Peer_presentation;
library(ggplot2)
#Chapter 2
#Caluclator Measure: 
1/200*30

(59+73+2) / 3

sin(pi/2)

#functionname_(,)
seq(1,10)

#input
x <- 3*4 

x <- "hello world"

#Apply
y <- seq(1,10, length.out = 5)


#Chapter 5.4
ggplot(data = diamonds) +
  geom_bar(mapping = aes(x = cut))

ggplot(data = diamonds) + 
  geom_histogram(mapping = aes(x = carat), binwidth = 0.5)

smaller <- diamonds %>%
  filter(carat < 3)
ggplot(data = smaller, mapping = aes(x = carat)) + 
  geom_histogram(binwidth = 0.1)

ggplot(data = smaller, mapping = aes(x = carat, color = cut)) + 
  geom_freqpoly(binwidth = 0.1)

ggplot(data = faithful, mapping = aes(x =carat)) +
  geom_histogram(binwidth = 0.01)

ggplot(data = faithful, mapping = aes(x = eruptions)) +
  geom_histogram(binwidth = 0.25)

ggplot(diamonds) +
  geom_histogram(mapping = aes(x = y),binwidth = 0.5)

ggplot(diamonds) + 
  geom_histogram(mapping = aes(x = y),binwidth = 0.5) +
  coord_cartesian(ylim = c(0,50))

#Chapter 5.5 
geom_freqpoly() 的默认外观不太适合这种比较，
因为高度是由计数给出的。这就意味着，如果一组观测的数量明显少于其他组的话，
就很难看出形状 上的差别。举个例子，我们探索一下钻石价格是如何随着质量而变化的:
  ggplot(data = diamonds, mapping = aes(x = price)) +
  geom_freqpoly(mapping = aes(color = cut), binwidth = 500)
很难看出分布上的差别，因为总体看来各组数量的差别太大了:
  ggplot(diamonds) +
  geom_bar(mapping = aes(x = cut))
为了让比较变得更容易，需要改变 y 轴的显示内容，不再显示计数，而是显示密度。
密度是对计数的标准化，这样每个频率多边形下边的面积都是 1:
  ggplot( 
    data = diamonds,
    mapping = aes(x = price, y = ..density..) )+
  geom_freqpoly(mapping = aes(color = cut), binwidth = 500)
显示出一般钻石(质量最差)的平均价格是最高的!
  
  使用 geom_boxplot() 函数查看按切割质量分类的价格分布: 
  ggplot(data = diamonds, mapping = aes(x = cut, y = price)) +
  geom_boxplot()

例如，我们看一下 mpg 数据集中的 class 变量。
你可能很想知道公路里程因汽车类别的不 同会有怎样的变化:
  ggplot(data = mpg, mapping = aes(x = class, y = hwy)) +
  geom_boxplot()

为了更容易发现趋势，可以基于 hwy 值的中位数对 class 进行重新排序:
  ggplot(data = mpg) +
  geom_boxplot(
    mapping = aes(
      x = reorder(class, hwy, FUN = median),
      y = hwy
    ) )

如果变量名很长，那么将图形旋转 90 度效果会更好一些。你可以通过 coord_flip() 函数 完成这一操作:
  ggplot(data = mpg) +
  geom_boxplot(
    mapping = aes(
      x = reorder(class, hwy, FUN = median),
      y = hwy
    ) )+
  coord_flip()

两个分类变量
使用内置的 geom_count() 函数: 
  ggplot(data = diamonds) +
  geom_count(mapping = aes(x = cut, y = color))
接着使用 geom_tile() 函数和填充图形属性进行可视化表示:
  diamonds %>%
  count(color, cut) %>%
  ggplot(mapping = aes(x = color, y = cut)) +
  geom_tile(mapping = aes(fill = n))

两个连续变量
可视化表示，使用 geom_point() 画出散点图。
你可以将相关变动看作点的模式。
例如，你可以看到钻石的克 拉数和价值之间存在一种指数关系:
  ggplot(data = diamonds) +
  geom_point(mapping = aes(x = carat, y = price))

使用 alpha 图形属性添加透明度:
  ggplot(data = diamonds) +
  geom_point(
    mapping = aes(x = carat, y = price),
    alpha = 1 / 100
  )
但是很难对特别大的数据集使用透明度。另一种解决方法是使用分箱。
這裡展示geom_bin2d() 和 geom_hex() 函数在两个维度上进行分箱。
geom_bin2d() 和 geom_hex() 函数将坐标平面分为二维分箱，并使用一种填充颜色
表示落入 每个分箱的数据点。geom_bin2d() 创建长方形分箱。geom_hex() 创建六边形分箱。
要想使 用 geom_hex()，需要安装 hexbin 包:
  
ggplot(data = smaller) +
  geom_bin2d(mapping = aes(x = carat, y = price))

install.packages("hexbin") 
library(hexbin)
ggplot(data = smaller) +
geom_hex(mapping = aes(x = carat, y = price))

另一种方式是对一个连续变量进行分箱，因此这个连续变量的作用就相当于分类变量。接 下来就可以使用前面学过的对分类变量和连续变量的组合进行可视化的技术了。例如，你 可以对 carat 进行分箱，然后为每个组生成一个箱线图:
  ggplot(data = smaller, mapping = aes(x = carat, y = price)) +
  geom_boxplot(mapping = aes(group = cut_width(carat, 0.1)))

以上示例使用了 cut_width(x, width) 函数将 x 变量分成宽度为 width 的分箱。默认情况 下，不管其中有多少个观测，箱线图看上去都差不多(除了离群点的数量不同)，因此很 难分辨出每个箱线图是对不同数量的观测进行摘要统计的。如果想要体现这种信息，可以 使用参数 varwidth = TRUE 让箱线图的宽度与观测数量成正比。
另一种方法是近似地显示每个分箱中的数据点的数量，此时可以使用 cut_number() 函数: 
ggplot(data = smaller, mapping = aes(x = carat, y = price)) +
  geom_boxplot(mapping = aes(group = cut_number(carat, 20)))




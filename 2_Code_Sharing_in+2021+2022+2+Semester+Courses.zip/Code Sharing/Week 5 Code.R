#Chapter 8.1 - 8.3
library(tidyverse)
当运行 read_csv() 时，它会打印一份数据列说明，给出每个列的名称和类型。这是 readr 的一项重要功能
read_csv("a,b,c
1,2,3
4,5,6")
有时文件开头会有好几行元数据。你可以使用skip = n来跳过前n行;或者使用 comment = "#" 
来丢弃所有以 # 开头的行:
read_csv("The first line of metadata
       The second line of metadata
       x,y,z
       1,2,3", skip = 2)
read_csv("# A comment I want to skip
       x,y,z
       1,2,3", comment = "#")
\n" 是非常便捷的快捷方式，用于添加新行
数据没有列名称。可以使用col_names = FALSE来通知read_csv()不要将第一行作为列 标题，
而是将各列依次标注为 X1 至 Xn:
  read_csv("1,2,3\n4,5,6", col_names = FALSE)
  
或者你也可以向 col_names 传递一个字符向量，以用作列名称:
read_csv("1,2,3\n4,5,6", col_names = c("x", "y", "z"))
na：它设定使用哪个值(或哪些值)来表示文件中的缺失值:
read_csv("a,b,c\n1,2,.", na = ".")
使用 read_tsv() 函数来读取制表符分隔文件，或使用 read_fwf() 函数来读取固定宽度的文件
8.3 解析向量
1.数字
parse_*() 函数族。这些函数接受一个字符向量，并返回一个特定向量，如逻辑、整数或日期向量:
parse_integer(c("1", "231", ".", "456"), na = ".")
错误情况
x <- parse_integer(c("123", "345", "abc", "123.45"))
如果解析失败的值很多，那么就应该使用 problems() 函数来获取完整的失败信息集合。这 
个函数会返回一个 tibble，你可以使用 dplyr 包来进行处理
problems(x)
解析失败的值在输出中是以缺失值的形式存在的
解析数值
小数点
在解析数值时，最重要的选项就是用来表示小数点的字符。
法一：
parse_double("1.23")
法二通过创建一个 新的地区对象并设定 decimal_mark 参数
parse_double("1,23", locale = locale(decimal_mark = ","))
忽视符号，提取数值
arse_number() 解决了第二个问题:它可以忽略数值前后的非数值型字符。这个函数特别 
适合处理货币和百分比，也可以提取嵌在文本中的数值:
parse_number("$100")
parse_number("20%")
parse_number("It cost $123.45")
分组问题
# 适用于美国 
parse_number("$123,456,789") 
# 适用于多数欧洲国家 
parse_number(
      "123.456.789",
       locale = locale(grouping_mark = ".")
     )
# 适用于瑞士 
parse_number(
       "123'456'789",
       locale = locale(grouping_mark = "'")
     )
2.字符character
在 R 中，我们可以使用 charToRaw() 函数获得一个字符串的底层 表示十六进制:
charToRaw("Hadley")
这个示例中的编码方式称为 ASCII。ASCII 可以非常好地表示英文字符
Latin1(即 ISO-8859-1，用于西欧语言) 
Latin2(即 ISO-8859-2，用于东欧语言)
UTF-8 可以为现在人类使用的所有字符进行编码，同时还支持很多特殊字符(如 表情符号!)。
不支持  x1 <- "El Ni\xf1o was particularly bad this year"
     x2 <- "\x82\xb1\x82\xf1\x82\xc9\x82\xbf\x82\xcd"
     UTF-8 需要在 parse_character() 函数中设定编码方式
parse_character(x1, locale = locale(encoding = "Latin1"))
parse_character(x2, locale = locale(encoding = "Shift-JIS"))
guess_encoding() 函数来帮助找出编码方式
guess_encoding(charToRaw(x1)) 
guess_encoding(charToRaw(x2)) 
集合中的因子
只要存在向量中没有的值，就会生成一条警告:
fruit <- c("apple", "banana")
parse_factor(c("apple", "banana", "bananana"), levels = fruit)
3.时间
3 种解析函数
• parse_datetime() 按从大到小的顺序排列，即年、月、日、小时、分钟、秒:
parse_datetime("2010-10-01T2010") 
# 如果时间被省略了，那么它就会被设置为午夜 
parse_datetime("20101010")
• parse_date() 年、月、日: 
parse_date("2010-10-01")
• parse_time() 时、分、（秒，a.m./p.m. 标识符可选）:
library(hms) 
因为 R 基础包中没有能够很好表示时间数据的内置类，所以我们使用 hms 包提供的时间类
parse_time("01:10 am") 
parse_time("20:10:01")
设计自己的时间格式以满足数据要求。
找出正确格式的最好方法是创建几个解析字符向量的示例，并使用某种解析函数进行测
试。例如:
parse_date("01/02/15", "%m/%d/%y") 
parse_date("01/02/15", "%d/%m/%y") 
parse_date("01/02/15", "%y/%m/%d") 
#For Chapter 8.4-8.6
解析文件
challenge <- read_csv(readr_example("challenge.csv"))  #输入文件
challenge
spec(challenge)  #查看规范
problems(challenge)  #检查问题


challenge <- read_csv(
  readr_example("challenge.csv"),  #更改规范
  col_types = cols(
    x = col_integer(),
    y = col_character()
  )
)

problems(challenge)

challenge <- read_csv(
  readr_example("challenge.csv"),
  col_types = cols(
    x = col_double(),
    y = col_character()
  )
)

problems(challenge)

tail(challenge)  #检查尾部

challenge <- read_csv(
  readr_example("challenge.csv"),
  col_types = cols(
    x = col_double(),
    y = col_date()
  )
)

head(challenge)

problems(challenge)

challenge2 <- read_csv(
  readr_example("challenge.csv"),
  guess_max = 1001
)

challenge2

challenge2 <- read_csv(readr_example("challenge.csv"),
                       col_types = cols(.default = col_character())
)

problems(challenge2)

df <- tribble(
  ~x, ~y,
  "1", "1.21",
  "2", "2.32",
  "3", "4.56"
)

df

type_convert(df)

#写入文件

data <- data.frame(姓名 = c("张三", "李四", "王五"), 体重 = c(50, 70, 80), 视力 = c(5.0, 4.8, 5.2)) #addition

data

write.csv(data, file = "data.csv")

write.csv(data,"data2.csv")   #可以省略

newdata <- read.csv(file = "data.csv", header = TRUE)

newdata

data1 <- data  #更改规范
col_types = cols(
  姓名 = col_number(),
  体重 = col_character()
)

type_convert(data1)

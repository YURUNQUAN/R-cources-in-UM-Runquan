install.packages("effsize")
install.packages("pwr")
install.packages("ggpubr")

library(ggplot2)
library(effsize)
library(pwr)
library(tibble)
library(ggpubr)
library(gridExtra)
options(scipen = 200)

read.csv("/Users/yu.run.q/Desktop/week_5_data.csv")
A = read.csv("/Users/yu.run.q/Desktop/week_5_data.csv")
A <- read.csv("/Users/yu.run.q/Desktop/week_5_data.csv")
read.csv("/Users/yu.run.q/Desktop/week_5_data.csv")
A = read.csv("/Users/yu.run.q/Desktop/week_5_data.csv")

#Correlation:相关
p1 <- ggscatter(A,x="Grade_1",y="Grade_2",color="#009999",size=3,xlab="Hightrust",ylab="Lowtrust",add="reg.line",add.params = list(color="black",fill="gray"),conf.int=TRUE)
p1
p1+stat_cor()

#Application: 
  
ggplot(data = A)+
  geom_point(mapping = aes(x = Condition, y = Grade))









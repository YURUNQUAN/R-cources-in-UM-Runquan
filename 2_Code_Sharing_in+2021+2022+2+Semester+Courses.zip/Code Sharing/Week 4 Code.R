# code for Week_4_Peer_presentation;

#chapter 5
library(ggplot2)

ggplot(data = faithful) +
  geom_point(mapping = aes(x = eruptions, y = waiting))


library(modelr)

mod <- lm(log(price) ~ log(carat), data = diamonds)
diamonds2 <- diamonds %>%
  add_residuals(mod) %>%
  mutate(resid = exp(resid))

ggplot(data = diamonds2) +
  geom_point(mapping = aes(x = carat, y = resid))

ggplot(data = diamonds2) +
  geom_boxplot(mapping = aes(x = cut, y = resid))


ggplot(data = faithful, mapping = aes(x = eruptions)) +
  geom_freqpoly(binwidth = 0.25)

diamonds %>%
  count(cut, clarity) %>%
  
  ggplot(aes(clarity, cut, fill = n)) +
  geom_tile()










#chapter 7

library(tibble)

as_tibble(iris)

tibble(
  x = 1:5,
  y = 1,
  z = x ^ 2 + y
)

tb <- tibble(
  `:)` = "smile",
  ` ` = "space",
  `2000` = "number"
)
tb

tribble(
  ~x, ~y, ~z,
  #--|--|----
  "a", 2, 3.6,
  "b", 1, 8.5
)

tibble(
  a = lubridate::now() + runif(1e3) * 86400,
  b = lubridate::today() + runif(1e3) * 30,
  c = 1:1e3,
  d = runif(1e3),
  e = sample(letters, 1e3, replace = TRUE)
)


nycflights13::flights %>%
  print(n = 10, width = Inf)

options(tibble.print_max = n, tibble.pring_min = m)
options(tibble.print_min = Inf)
options(tibble.width = Inf)

nycflights13::flights %>%
  View()

df <- tibble(
  x = runif(5),
  y = rnorm(5)
)

df$x
df[["x"]]
df[[1]]

df %>% .$x
df %>% .[["x"]]

class(as.data.frame(tb))
#> [1] "data.frame"


install.packages("effsize")
install.packages("pwr")
install.packages("ggpubr")

#print the gg-format graph
library(ggplot2) #(from chapter 1)
#Because we had install the above packages, we are supposed to library it. 
#From line 9-14, is the code for the correlation, 
#regression and tibble that for the scale print the data statistically. 
library(effsize)
library(pwr)
library(tibble) #(From chapter 7)
library(ggpubr)
library(gridExtra)
options(scipen = 200)

#Belows, we have studied from Chapter 2 and Chapter 8. 
#Put the excel documents and data into R-studio. 
read.csv("/Users/yu.run.q/Desktop/Dataset1.csv")
A1=read.csv("/Users/yu.run.q/Desktop/Dataset1.csv")
ggplot(data = A1)+
  geom_point(mapping = aes(x = Sleep, y= NA))

read.csv("/Users/yu.run.q/Desktop/Dataset2.csv")
A2=read.csv("/Users/yu.run.q/Desktop/Dataset2.csv")

read.csv("/Users/yu.run.q/Desktop/Dataset3.csv")
A3=read.csv("/Users/yu.run.q/Desktop/Dataset3.csv")

P1 <- ggscatter(A2,x="X",y="Y",color="#009999",size=3,xlab="Hightrust",ylab="Lowtrust",add="reg.line",add.params = list(color="black",fill="gray"),conf.int=TRUE)
P1
p1+stat_cor()

ggplot(data = A2)+
  geom_point(mapping = aes(x = Condition, y = Grade))

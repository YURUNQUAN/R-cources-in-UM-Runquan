

install.packages("tidyverse")
library(tidyverse) 
#1.2數據框；readr example.數據框的格式及其閱讀
#1.2.1 mpg數據框的含義（ggplot2 數據框的應用）
你可以使用 ggplot2 包中的 mpg 数据框（即 ggplot2::mpg）来检验自己的答案。数据框是
变量（列）和观测（行）的矩形集合。
  “mpg”數據框的含義：
#> # A tibble: 234 × 11
#>   manufacturer model displ year  cyl       trans    drv
#>          <chr> <chr> <dbl> <int> <int>     <chr>   <chr>
#> 1        audi  a4    1.8   1999   4      auto(l5)     f
#> 2        audi  a4    1.8   1999   4    manual(m5)     f
#> 3        audi  a4    2.0   2008   4    manual(m6)     f
#> 4        audi  a4    2.0   2008   4      auto(av)     f
#> 5        audi  a4    2.8   1999   6      auto(l5)     f
#> 6        audi  a4    2.8   1999   6    manual(m5)     f
#> # ... with 228 more rows, and 4 more variables:
#> # cty <int>, hwy <int>, fl <chr>, class <chr>
plus：觀測行一般只能顯示6行。變量列一般可以顯示7列。

#1.2.2 創建ggplot圖形
（1）#繪製mpg圖形，將代碼displ放在x軸， hwy放在y軸
#displ是引擎的大小，hwy代表的是燃油效率。
ggplot( data = mpg )+
  geom_point( mapping = aes( x= displ, y = hwy))
• displ：引擎大小，单位为升。
• hwy：汽车在高速公路上行驶时的燃油效率，单位为英里 / 加侖。
#其中ggplot ( data = mpg) 是函數的名稱。
#geom_point 中的 point代表的是圖像中的“點”狀（散點）
#mapping是對應的幾何參數，和對應的aes相對應。
#aes中的x，y對應的是x軸，y軸。

#1.2.3.繪圖模板
ggplot(data = <DATA>) +
  <GEOM_FUNCTION>(mapping = aes(<MAPPINGS>))
ggplot(data =mpg)+
  geom_point(mapping = aes(x= displ, y = hwy))

#1.2.4. 練習 
(1) 运行 ggplot(data = mpg)，你会看到什么？
ggplot(data = mpg)
(2) 数据集 mpg 中有多少行？多少列？
(3) 使用 hwy和cyl繪製一張散點圖
TBC

#1.3 圖形的屬性映射
通過將圖中的圖形屬性映射為數據集中的變量，可以傳達數據的相關信息。例如：
可以將點的顏色映射為變量 class， 提示每輛車的類型。
ggplot(data = mpg)+
  geom_point(mapping = aes(x = displ, y = hwy, color = class))
#class 映射為顏色
ggplot( data = mpg)+
  geom_point(mapping = aes( x = displ, y = hwy, size = class))
alpha 透明度屬性
ggplot( data = mpg)+
  geom_point(mapping = aes( x= displ, y = hwy, alpha = class))
shape 屬性原則
ggplot(data = mpg)+
  geom_point(mapping = aes(x = displ, y = hwy, shape = class))
#最多只能表現出六種形狀。         
#對於給圖中信息添加顏色
ggplot(data = mpg)+
  geom_point(mapping = aes(x = displ, y = hwy), color = "red")
#Practise:here(綜合運用)
#
#

#1.4 常見問題
#表達式不完整
ggplot(data = mpg)+
  geom_point(mapping = aes(x = displ, y = hwy, shape = c
                           
#"+"號放錯位置

ggplot(data = mpg)
  +geom_point(mapping = aes(x = displ, y = hwy), color = "red")

#查看幫助界面
#在控制台中运行 ? 函数名，或者在 RStudio中选定函数名称后按 F1 键，
?ggplot

#google

#1.5分面
#原圖表
ggplot( data = mpg)+
  geom_point(mapping = aes( x = displ, y = hwy, size = class))

#一個變量分面
ggplot(data = mpg) +
  geom_point(mapping = aes(x = displ, y = hwy)) +
  facet_wrap(~ class, nrow = 2)

#兩個變量分面
ggplot(data = mpg) +
  geom_point(mapping = aes(x = displ, y = hwy)) +
  facet_grid(drv ~ cyl)

#Q1
#遇到連續變量會怎麽樣
ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point() +
  facet_grid(. ~ cty)
#连续变量将转换为分类变量，并且绘图包含每个不同值的构面。

#Q2
#在使用 facet_grid(drv ~ cyl) 生成的图中，空白单元的意义是什么？
#它们和以下代码生成的图有什么关系？
ggplot(data = mpg) +
  geom_point(mapping = aes(x = drv, y = cyl))


ggplot(data = mpg) +
  geom_point(mapping = aes(x = hwy, y = cty)) +
  facet_grid(drv ~ cyl)


ggplot(data = mpg) +
  geom_point(mapping = aes(x = drv, y = cyl))




#Q3
#以下代码会绘制出什么图？ . 的作用是什么？
ggplot(data = mpg) +
  geom_point(mapping = aes(x = displ, y = hwy)) +
  facet_grid(drv ~ .)
ggplot(data = mpg) +
  geom_point(mapping = aes(x = displ, y = hwy)) +
  facet_grid(. ~ cyl)

#Q4
#与使用图形属性相比，使用分面的优势和劣势分别是什么？如果有一个更大的数据集，你将如何权衡这两种方法的优劣？
ggplot(data = mpg) +
  geom_point(mapping = aes(x = displ, y = hwy)) +
  facet_wrap(~class, nrow = 2)

ggplot(data = mpg) +
  geom_point(mapping = aes(x = displ, y = hwy, color = class))


#Q5
#阅读 ?facet_wrap 的帮助页面。nrow 和 ncol 的功能分别是什么？
#还有哪些选项可以控制分面的布局？
#为什么函数 facet_grid() 没有变量 nrow 和 ncol ？

?facet_wrap 


#参数nrow（ncol）确定布局构面时要使用的行数（列）。
#这是必要的，因为facet_wrap()仅在一个变量上具有多个方面。
#nrow和ncol参数是不必要的facet_grid()，
#因为在函数中指定的变量的唯一值的数量决定的行和列的数目。


#Q6
#在使用函数 facet_grid() 时，一般应该将具有更多唯一值的变量放在列上。为什么这么做呢？
#如果将图水平放置（横向），将有更多的列空间。


#1.6 geometric objects
#1.6.1幾何對象
#geom_point點圖
ggplot(data = mpg) + 
  geom_point(mapping = aes(x = displ, y = hwy))

#geom_smooth綫圖
ggplot(data = mpg) + 
  geom_smooth(mapping = aes(x = displ, y = hwy))

#通过改变line type增加categorical variable到图表
ggplot(data = mpg) + 
  geom_smooth(mapping = aes(x = displ, y = hwy, linetype = drv))
#用group添加categorical variable (不推荐)
ggplot(data = mpg) +
  geom_smooth(mapping = aes(x = displ, y = hwy, group = drv))#默認分組
#用Color添加 （最后一行代码隐藏了图例）
ggplot(data = mpg) +
  geom_smooth(
    mapping = aes(x = displ, y = hwy, color = drv),
    show.legend = FALSE#圖例
  )

#KEY POINT：display multiple geoms in the same plot
ggplot(data = mpg) + 
  geom_point(mapping = aes(x = displ, y = hwy)) +
  geom_smooth(mapping = aes(x = displ, y = hwy))

#省略代码：在ggplot()中mapping
ggplot(data = mpg, mapping = aes(x = displ, y = hwy)) + 
  geom_point() + 
  geom_smooth()


#使用global mapping的同时，可以使用local mapping.
ggplot(data = mpg, mapping = aes(x = displ, y = hwy)) + 
  geom_point(mapping = aes(color = class)) + 
  geom_smooth()

#在layer里面使用总数据中的一小部分
ggplot(data = mpg, mapping = aes(x = displ, y = hwy)) + 
  geom_point(mapping = aes(color = class)) + 
  geom_smooth(data = filter(mpg, class == "subcompact"), se = FALSE)

#exercise
#1.What geom would you use to draw a line chart? 
#在绘制折线图、箱线图、直方图和分区图时，应该分别使用哪种几何对象？
#A boxplot? A histogram? An area chart?
#A：line chart: geom_line()   boxplot: geom_boxplot()  histogram: geom_histogram()  area chart: geom_area()

#2.guess then run code
ggplot(data = mpg, mapping = aes(x = displ, y = hwy, color = drv)) + 
  geom_point() + 
  geom_smooth(se = FALSE)#Se 是散点边上的灰色拟合区

#3.Q：What does show.legend = FALSE do?
#A：隐藏图例框
#Q:What happens if you remove it?
#A：导致该图具有图例显示颜色和drv之间的映射
#Q：Why do you think I used it earlier in the chapter?
#A：在章节里早点考虑 方便理解

#4.Q：What does the se argument to geom_smooth() do?
# A：It adds standard error bands to the lines.
# A：它将标准误差带添加到行中。

#5.Q：Will these two graphs look different? Why/why not?
ggplot(data = mpg, mapping = aes(x = displ, y = hwy)) + 
  geom_point() + 
  geom_smooth()

ggplot() + 
  geom_point(data = mpg, mapping = aes(x = displ, y = hwy)) + 
  geom_smooth(data = mpg, mapping = aes(x = displ, y = hwy))

#A：使用相同的数据 不需要再次输入代码 本质上是一致


#6.Recreate the R code necessary 
#  to generate the following graphs.看答案頁

#1
l<-ggplot(mpg,aes(displ,hwy))
l+geom_point()+
  geom_smooth(se=FALSE)

#2
l+geom_point()+
  geom_smooth(aes(group=drv),se=FALSE)

#3
l+geom_point(aes(color=drv))+
  geom_smooth(aes(color=drv),se=FALSE)

#4
l+geom_point(aes(color=drv))+
  geom_smooth(se=FALSE)

#5
l+geom_point(aes(color=drv))+
  geom_smooth(aes(linetype=drv),se=FALSE)


#6(需要改变stroke的颜色)
l+geom_point(aes(color=drv))
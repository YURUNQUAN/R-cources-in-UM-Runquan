library(ggplot2)
library(car)

install.packages(mtcars)
head(mtcars)
p = ggplot(mtcars, aes(x=mpg,y=wt))
p + geom_point()
p + geom_point(aes(color=factor(cyl)))

ggplot(data = mtcars)+
  geom_smooth(mapping = aes(x=mpg,y=wt))

ggplot(data = mtcars )+
  geom_point(mapping = aes(x=mpg,y=wt))+
  geom_smooth(mapping = aes(x=mpg,y=wt))
attach(mtcars) 
plot(wt, mpg, 
     main="Basic Scatter plot of MPG vs. Weight", 
     xlab="Car Weight (lbs/1000)", 
     ylab="Miles Per Gallon ", pch=19) 
abline(lm(mpg~wt), col="red", lwd=2, lty=1) 
lines(lowess(wt,mpg), col="blue", lwd=2, lty=2)

library(car) 
scatterplot(mpg ~ wt | cyl, data=mtcars, lwd=2, span=0.75, 
            main="Scatter Plot of MPG vs. Weight by # Cylinders", 
            xlab="Weight of Car (lbs/1000)", 
            ylab="Miles Per Gallon", 
            legend.plot=TRUE)


#分析“男性成年对于自己身体意向的评分”与“男性成年自杀倾向的的分数”之间的关系

Dataset<-read.csv("Dataset3.csv")
Dataset

ggplot(data = Dataset)+
  geom_point(mapping = aes(x=mbodyimage,y=msuiside))

ggplot(data = Dataset)+
  geom_line(mapping = aes(x=mbodyimage,y=msuiside))

ggplot(data = Dataset)+
  geom_smooth(mapping = aes(x=mbodyimage,y=msuiside))

ggplot(data = Dataset)+
  geom_point(mapping = aes(x=mbodyimage,y=msuiside))+
  geom_smooth(mapping = aes(x=mbodyimage,y=msuiside))

a <- ggscatter(Dataset,x="mbodyimage",y="msuiside",color="#00999999",size=3,xlab="mbodyimage",ylab="msuiside",add="reg.line",add.params = list(color="pink",fill="pink"),conf.int=TRUE)
a
a+stat_cor()


#分析Dataset2
Dataset<-read.csv("Dataset2.csv")
Dataset

ggplot(data=Dataset, mapping = aes(x = Condition, y = Group))+
  geom_point()+
  geom_line(aes(group = Sub))


#分析Dataset1
Dataset<-read.csv("Dataset1.csv")
Dataset
ggplot(data = Dataset)+
  geom_bar(mapping = aes(x = Sleep))

a <- ggscatter(Dataset,x="Emotion",y="Happiness",color="#009999",size=3,xlab="Emotion",ylab="Happiness",add="reg.line",add.params = list(color="pink",fill="pink"),conf.int=TRUE)
a
a+stat_cor()

b <- ggscatter(Dataset,x="Emotion",y="Sleep",color="#009999",size=3,xlab="Emotion",ylab="Sleep Quality",add="reg.line",add.params = list(color="pink",fill="pink"),conf.int=TRUE)
b
b+stat_cor()


